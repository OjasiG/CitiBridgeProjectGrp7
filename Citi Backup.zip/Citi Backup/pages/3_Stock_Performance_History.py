# import pandas as pd
# from pandas_datareader import data, wb
import yfinance as yf
import plotly.graph_objs as go
import streamlit as st

def bollingerBand(stock_ticker):
    data = yf.download(tickers=stock_ticker, start = '2021-05-22', end = '2023-05-22')
    # print(data)
    # print(list(data.columns))

    #Bollinger Bands
    #Get the average of the closing value of the last 20 days
    data['Middle Band'] = data['Close'].rolling(window = 20).mean()
    data['Lower Band'] = data['Middle Band'] - 1.96*data['Close'].rolling(window = 20).std()
    data['Upper Band'] = data['Middle Band'] + 1.96*data['Close'].rolling(window = 20).std()

    # print(data)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x = data.index, y = data['Middle Band'], line = dict(color = 'blue', width = .7), name = 'Middle Band'))
    fig.add_trace(go.Scatter(x = data.index, y = data['Upper Band'], line = dict(color = 'red', width = 1.5), name = 'Upper Band (Sell)'))
    fig.add_trace(go.Scatter(x = data.index, y = data['Lower Band'], line = dict(color = 'green', width = 1.5), name = 'Lower Band (Buy)'))

    fig.add_trace(go.Candlestick(x=data.index,
                open=data['Open'],
                high=data['High'],
                low=data['Low'],
                close=data['Close'], name = 'market data'))

    # fig.show()
    st.plotly_chart(fig)
    # fig.savefig('plot.png')
    # st.pyplot(fig)
    # st.image('plot.png')


stock_ticker = st.text_input('Enter a constituent: ')
if st.button('Generate'):
    bollingerBand(stock_ticker)