from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import pandas as pd
import time
import streamlit as st


st.title('Stock Recommendation')

# Set the path to the ChromeDriver executable
driver_path = "C:/Users/dell/Documents/TYBTech Sem II/CitiBridge_Project/Selenium/chromedriver.exe"
s=Service(driver_path)
driver = webdriver.Chrome(service = s)


def get_user_choice():
    market_cap = ['Large','Mid','Small']
    choice = st.selectbox("Select a Market Cap: ", market_cap)
    return choice


def small():
    driver.get("https://www.moneycontrol.com/markets/indian-indices/top-nsesmlcap-50-companies-list/113?classic=true&categoryId=1&exType=N")


def mid():
    driver.get("https://www.moneycontrol.com/markets/indian-indices/top-nsemidcap-50-companies-list/31?classic=true&categoryId=5&exType=N")


def large():
    driver.get("https://www.moneycontrol.com/markets/indian-indices/top-nse-50-companies-list/9?classic=true&categoryId=1&exType=N")


def exec():
    st.write('')
    st.header(f'{choice} Cap Constituents:')
    # Find the table body (For Overview)
    tbody = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/tbody')
    thead = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/thead')
    headers = thead.find_elements(By.XPATH, './/th')

    titles = []
    for i in headers:
        title = i.text
        titles.append(title)

    print(titles)

    table = pd.DataFrame(columns=titles)

    # Find the table body
    tbody = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/tbody')

    # Extract the table data
    for row in tbody.find_elements(By.XPATH, './/tr'):
        row_data = [item.text for item in row.find_elements(By.XPATH, './/td')]
        l = len(table)
        table.loc[l] = row_data

    df_temp1 = table[['Name','LTP','%Chg','Volume','Buy Price','Sell Price','Buy Qty','Sell Qty']]
    print(df_temp1)
    st.dataframe(df_temp1)

    st.write('')
    st.header('Top 5 Performing Stocks:')

    #Fundamental code
    time.sleep(1)

    button = driver.find_element("link text",'Fundamental')
    button.click()

    time.sleep(2)

    # Find the table body (For Fundamental)
    tbody = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/tbody')
    thead = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/thead')
    headers = thead.find_elements(By.XPATH, './/th')

    titles = []
    for i in headers:
        title = i.text
        titles.append(title)

    print(titles)

    tables = pd.DataFrame(columns=titles)

    # Find the table body
    tbody = driver.find_element(By.XPATH, '//*[@id="indicesTable"]/tbody')

    # Extract the table data
    for row in tbody.find_elements(By.XPATH, './/tr'):
        row_data = [item.text for item in row.find_elements(By.XPATH, './/td')]
        l = len(tables)
        tables.loc[l] = row_data

    # print(tables)
    df_temp2 = tables[['P/E','Debt to Equity','EPS(Rs.)','Net Profit(Rs. Cr)','ROE%']]
    df = pd.concat([df_temp1, df_temp2], axis=1, join='inner')

    for ind in df.index:
        if(float(df['Debt to Equity'][ind].replace(',', '')) > 2 or float(df['P/E'][ind].replace(',', ''))>=30 or float(df['P/E'][ind].replace(',', ''))<10 or float(df['ROE%'][ind].replace(',', ''))<10):
            # print(df['Debt to Equity'][ind])
            df.drop([ind], axis=0, inplace=True)

    df['EPS(Rs.)'] = df['EPS(Rs.)'].astype(float)
    st.dataframe(df.sort_values('EPS(Rs.)', ascending=False).head(5))




#Main program
choice = get_user_choice()
if choice == 'Mid':
    mid()
elif choice == 'Small':
    small()
elif choice == 'Large':
    large()
else:
    st.warning('Make a selection')
# time.sleep(1)
if st.button('Select'):
    exec()